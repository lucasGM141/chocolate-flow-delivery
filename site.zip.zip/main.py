from flask import Flask, request, render_template, redirect, url_for, flash
import sqlite3
from produto import Produto
from produto_dao import ProdutoDAO

app = Flask(__name__)
# O Flask exige uma chave secreta para mandar mensagens de erro/sucesso com segurança
app.secret_key = 'chave_super_secreta_da_loja' 
dao = ProdutoDAO()

# ROTA 1: Carrega a tela HTML com a lista de produtos
@app.route('/')
def home():
    todos_produtos = dao.listar_todos()
    return render_template('produtos_lista.html', produtos=todos_produtos)

# ROTA 2: Abre a tela do formulário de cadastro
@app.route('/novo')
def novo_produto():
    return render_template('produtos_formulario.html')

# ROTA 3: Recebe os dados do formulário e salva no banco
@app.route('/salvar', methods=['POST'])
def salvar():
    nome = request.form.get('nome')
    descricao = request.form.get('descricao')
    preco = float(request.form.get('preco'))
    
    novo_chocolate = Produto(nome=nome, descricao=descricao, preco=preco)
    dao.salvar(novo_chocolate)
    
    flash(f'Chocolate "{nome}" cadastrado com sucesso!')
    return redirect(url_for('home'))

# ROTA 4: Cria a tabela no banco de dados
@app.route('/instalar')
def instalar_banco():
    conexao = sqlite3.connect('chocolate.db')
    conexao.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            descricao TEXT,
            preco REAL NOT NULL
        )
    ''')
    conexao.close()
    return "<h1>✅ Banco de dados 'chocolate.db' criado com sucesso!</h1><p><a href='/'>Ir para a Página Inicial</a></p>"

# ROTA 5: Deletar um produto pelo ID
@app.route('/deletar/<int:id>')
def deletar(id):
    conexao = sqlite3.connect('chocolate.db')
    conexao.execute('DELETE FROM produtos WHERE id = ?', (id,))
    conexao.commit()
    conexao.close()
    
    flash('Chocolate excluído do sistema.')
    return redirect(url_for('home'))

# ROTA 6: Abre a tela de edição
@app.route('/editar/<int:id>')
def editar(id):
    conexao = sqlite3.connect('chocolate.db')
    cursor = conexao.cursor()
    cursor.execute('SELECT id, nome, descricao, preco FROM produtos WHERE id = ?', (id,))
    linha = cursor.fetchone()
    conexao.close()
    
    if linha:
        produto_encontrado = Produto(nome=linha[1], descricao=linha[2], preco=linha[3])
        return render_template('produtos_editar.html', produto=produto_encontrado, id_chocolate=id)
    
    return redirect(url_for('home'))

# ROTA 7: Recebe os dados novos e atualiza o banco de dados
@app.route('/atualizar/<int:id>', methods=['POST'])
def atualizar(id):
    nome = request.form.get('nome')
    descricao = request.form.get('descricao')
    preco = float(request.form.get('preco'))
    
    conexao = sqlite3.connect('chocolate.db')
    conexao.execute('UPDATE produtos SET nome = ?, descricao = ?, preco = ? WHERE id = ?', (nome, descricao, preco, id))
    conexao.commit()
    conexao.close()
    
    flash('Informações do chocolate atualizadas com sucesso!')
    return redirect(url_for('home'))

# ROTA 8: Busca produtos pelo nome (aproximação)
@app.route('/buscar')
def buscar():
    # Pega o que o usuário digitou na caixinha
    termo_digitado = request.args.get('termo')
    
    conexao = sqlite3.connect('chocolate.db')
    cursor = conexao.cursor()
    
    # Faz a mágica do LIKE: busca qualquer nome que CONTENHA o pedaço digitado
    pesquisa = f"%{termo_digitado}%"
    cursor.execute('SELECT id, nome, descricao, preco FROM produtos WHERE nome LIKE ?', (pesquisa,))
    linhas = cursor.fetchall()
    conexao.close()
    
    # Transforma o resultado do banco em uma lista que o HTML entenda
    produtos_encontrados = []
    for linha in linhas:
        p = Produto(nome=linha[1], descricao=linha[2], preco=linha[3])
        p.id = linha[0]
        produtos_encontrados.append(p)
        
    # Mostra a mesma tela inicial, mas APENAS com os produtos encontrados!
    return render_template('produtos_lista.html', produtos=produtos_encontrados)

if __name__ == '__main__':
    print("Servidor rodando! Abra seu navegador.")
    app.run(debug=True)
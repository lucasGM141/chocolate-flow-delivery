import sqlite3
from produto import Produto

class ProdutoDAO:
    def criar_conexao(self):
        return sqlite3.connect('chocolate.db')

    def salvar(self, produto):
        conexao = self.criar_conexao()
        cursor = conexao.cursor()
        sql = 'INSERT INTO produtos (nome, descricao, preco) VALUES (?, ?, ?)'
        cursor.execute(sql, (produto.nome, produto.descricao, produto.preco))
        conexao.commit()
        conexao.close()

    def listar_todos(self):
        conexao = self.criar_conexao()
        cursor = conexao.cursor()
        cursor.execute('SELECT id, nome, descricao, preco FROM produtos')
        linhas = cursor.fetchall()
        
        produtos_lista = []
        for linha in linhas:
            prod = Produto(id=linha[0], nome=linha[1], descricao=linha[2], preco=linha[3])
            produtos_lista.append(prod)
            
        conexao.close()
        return produtos_lista